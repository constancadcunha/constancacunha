# Designs Portfolio

This folder contains various design projects that showcase my creativity, skills, and experience. Each design was created with attention to detail and a focus on aesthetic appeal, usability, and functionality.

## Contents

- **Images**: Each design is stored as an image file for easy viewing.
- **Poster Designs**: High-quality posters created for events, recruitment, and promotional purposes.
- **Interactive Media**: Any PDF files or embedded media that were part of specific projects.

## How to View Designs

### Web Portfolio
These designs are also showcased on my [online portfolio](#https://www.linkedin.com/in/constanca-cunha/) (insert your portfolio link if applicable). Visit the site to see how they integrate into my overall design showcase.

### Local Preview
To view the designs locally:
1. Open the images using any standard image viewer.
2. For PDFs, use a PDF reader like Adobe Acrobat or your browser.

## Licensing

These designs are the intellectual property of Constança Cunha/SINFO. Please do not distribute or use these designs without prior permission.

## Contact

For inquiries, collaborations, or feedback, please feel free to contact me:

- **Email**: [your.email@example.com](mailto:constancadcunha@gmail.com)
- **Website**: [yourportfolio.com](#https://constancadcunha.github.io/constancacunha/)
- **LinkedIn**: [linkedin.com/in/yourprofile](#https://www.linkedin.com/in/constanca-cunha/)
